#ifndef QUIZ_H
#define QUIZ_H


class quiz
{
public:
    quiz();
};

#endif // QUIZ_H
