#ifndef TEST_H
#define TEST_H


class test{
private:
    bool testbool;

public:
    test(){testbool = false;}
    void setbool(bool b){
        testbool = b;
    }
};
#endif // TEST_H
