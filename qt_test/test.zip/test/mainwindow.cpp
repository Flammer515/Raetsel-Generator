#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <fstream>
#include <string>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <quiz.cpp>
#include <QXmlStreamReader>
#include <QtXml>
bool test = false;

using namespace std;
QString Frage;
QString tip;
qint16 wert;
qint16 tolleranz;

quiztest erstens;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
     ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //-ste text
    QString Name;
    QString description;
    QString difficulty;
    QString steps;
    QDomDocument xmlBom;
    QFile f("C:\\Users\\bobby\\OneDrive\\Studium\\3._Semester\\FProg\\qt_test\\test\\tester42.xml");
    if (!f.open(QIODevice::ReadOnly ))
    {
        // Error while loading file
        std::cerr << "Error while loading file" << std::endl;

    }
    xmlBom.setContent(&f);
    f.close();

    QDomElement root =xmlBom.documentElement();
    QString Type = root.tagName();

    QDomElement Raetsel=root.firstChild().toElement();

    while(!Raetsel.isNull()){
        if(Raetsel.tagName()=="Raetsel"){
            QDomElement Child=Raetsel.firstChild().toElement();


            while(!Child.isNull()){
                if(Child.tagName()=="name") Name = Child.firstChild().toText().data();
                if(Child.tagName()=="description") description = Child.firstChild().toText().data();
                if(Child.tagName()=="difficulty") difficulty = Child.firstChild().toText().data();
                if(Child.tagName()=="steps") steps = Child.firstChild().toText().data();

                Child = Child.nextSibling().toElement();
            }
        }

        ui->textBrowser->insertPlainText(Name);
        ui->textBrowser->insertPlainText(description);
        ui->textBrowser->insertPlainText(difficulty);
        ui->textBrowser->insertPlainText(steps);
        Raetsel = Raetsel.nextSibling().toElement();
    }




}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::keyPressEvent(QKeyEvent *event){
    qDebug()<<"Pressed Key: "<<(char)event->key();
}




void MainWindow::on_Button0_clicked()
{
    QFile file("C:\\Users\\bobby\\OneDrive\\Studium\\3._Semester\\FProg\\qt_test\\test\\tester42.xml");
    if(!file.open(QIODevice::ReadOnly))
        QMessageBox::information(0,"info",file.errorString());

    QTextStream in(&file);

    ui->textBrowser->setText(in.readAll());

}

void MainWindow::on_Start_clicked()
{






}
