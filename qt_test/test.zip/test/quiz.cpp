#include "quiz.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <fstream>
#include <string>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>


class quiztest
{
private:
    QString Frage;
    QString Tip;
    QString Fragentyp;
    QString Antwort;
    QString Tolleranz;

public:
    quiztest(){}
    quiztest(QString Frage, QString Tip,QString Fragentyp,QString Antwort, QString,QString Tolleranz){
        this->Frage = Frage;
        this->Tip = Tip;
        this->Fragentyp = Fragentyp;
        this->Antwort = Antwort;
        this->Tolleranz = Tolleranz;
    }
    QString getFrage(){
        return Frage;
    }

};

quiz::quiz()
{

}
